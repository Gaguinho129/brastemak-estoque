import React from 'react';

export default function EstoqueApp() {
  return (
    <div>
      <h1>Bem-vindo ao App de Estoque da Brastemak</h1>
      <p>Aqui vai o controle de peças, produtos e movimentações.</p>
    </div>
  );
}