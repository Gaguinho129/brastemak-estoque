import React from 'react';
import EstoqueApp from './components/EstoqueApp';

export default function App() {
  return (
    <div className="app-container">
      <EstoqueApp />
    </div>
  );
}